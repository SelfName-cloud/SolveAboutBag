using NUnit.Framework;
using SAB;
using System.Collections.Generic;

namespace TestForSolveAboutBag
{
    public class Tests
    {
        SolveAboutBag sab = new SolveAboutBag();

        [TestCase]
        public void TestForMethodCodeGray()
        {
            var input = new List<int>() { 1, 2, 3 };
            var expact = new List<string>() { "}", "1}", "2}", "12}", "3}", "13}", "23}", "123}" };

            Assert.AreEqual(expact, sab.CodeGray(input));



        }
        [TestCase]
        public void TestForMethodCodeGrayNothing()
        {
            var input = new List<int>() {  };
            var expact = new List<string>() {"}"};

            Assert.AreEqual(expact, sab.CodeGray(input));



        }
        [TestCase]
        public void TestForMethodCodeGrayWhiteSpace()
        {
            var input = new List<int>() { 1, };
            var expact = new List<string>() {"}", "1}"};

            Assert.AreEqual(expact, sab.CodeGray(input));

        }
        [TestCase]
        public void TestForMethodSolveAboutBag()
        {
            //expected
            var expact = "������ ���������: {123} ��������� ���������: 18 ��� ���������: 9";
            //input
            var Number = new List<int>() { 1, 2, 3, 4 };
            var Price = new List<int>() { 3, 6, 9, 2 };
            var Weight = new List<int>() { 4, 2, 3, 2 };
            int LimitWeight = 10;

            Assert.AreEqual(expact, sab.SolveAboutBagMethod(Number, Price, Weight, LimitWeight));
        }
        [TestCase]
        public void TestForMethodSolveAboutBagLimitWeight()
        {
            //expected
            var expact = "";
            //input
            var Number = new List<int>() { 1, 2, 3, 4 };
            var Price = new List<int>() { 3, 6, 9, 2 };
            var Weight = new List<int>() { 4, 2, 3, 2 };
            int LimitWeight = 0;

            Assert.AreEqual(expact, sab.SolveAboutBagMethod(Number, Price, Weight, LimitWeight));
        }
        [TestCase]
        public void TestForMethodSolveAboutBagLimitWeightMore()
        {
            //expected
            var expact = "������ ���������: {123} ��������� ���������: 11 ��� ���������: 3";
            //input
            var Number = new List<int>() { 1, 2, 3};
            var Price = new List<int>() { 3, 6, 2 };
            var Weight = new List<int>() { 1, 1, 1};
            int LimitWeight = 10;

            Assert.AreEqual(expact, sab.SolveAboutBagMethod(Number, Price, Weight, LimitWeight));
        }
        [TestCase]
        public void TestForMethodSolveAboutBagOneElement()
        {
            //expected
            var expact = "";
            //input
            var Number = new List<int>() {1};
            var Price = new List<int>() {3};
            var Weight = new List<int>() {20};
            int LimitWeight = 10;

            Assert.AreEqual(expact, sab.SolveAboutBagMethod(Number, Price, Weight, LimitWeight));
        }

        [TestCase]
        public void TestForMethodSolveAboutBagBigElement()
        {
            //expected
            var expact = "������ ���������: {1467} ��������� ���������: 2582 ��� ���������: 1415";
            //input
            var Number = new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            var Price = new List<int>() { 350, 469, 238, 987, 456, 567, 678, 223, 567};
            var Weight = new List<int>() { 126, 458, 348, 590, 445, 567, 132, 563, 356};
            int LimitWeight = 1500;

            Assert.AreEqual(expact, sab.SolveAboutBagMethod(Number, Price, Weight, LimitWeight));
        }
    }
}