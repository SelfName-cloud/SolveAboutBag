﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SAB
{
    struct DataForSolve
    {
        public List<int> Number;
        public List<int> Price;
        public List<int> Weight;
        public int LimitWeight;

       

        public DataForSolve(List<int> number, List<int> price, List<int> weight, int limitWeight) : this()
        {
            Number = number;
            Price = price;
            Weight = weight;
            LimitWeight = limitWeight;
        }
    }
}
