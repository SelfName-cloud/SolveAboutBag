﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SAB
{
    public class SolveAboutBag
    {
        List<string> sets = new List<string>();
        
        public List<string> LineSets = new List<string>();
        
        public List<string> CodeGray(List<int> set)
        {
            int w = set.Count();
            int i, j, n;
            n = (int)Math.Pow(2, w);
            for(i = 0; i < n; i++)
            {
                sets.Add("{");
                for( j = 0; j < w; j++)
                {
                    if ((i & (1 << j)) != 0)
                    {
                        sets.Add(set[j].ToString());
                    }

                }
                sets.Add("}");
            }


            return GetLineSets();
        }

        
        public List<string> GetLineSets()
        {
            string set = "";
            for(int i = 0; i < sets.Count; i++)
            {
                if(sets[i] == "{")
                {
                    while(sets[i] != "}")
                    {
                        i++;
                        set += sets[i];
                        
                    }
                    LineSets.Add(set);
                    set = "";

                }
            }

            return LineSets;

        }

        public string SolveAboutBagMethod(List<int> number, List<int> price, List<int> weight, int limitWeight)
        {
            int finalPrice = 0;
            int finalWeight = 0;
            string answerForSolve = "";
            int countPrice = 0;
            DataForSolve data = new DataForSolve(number, price, weight, limitWeight);

            var finalList = new List<string>();
            CodeGray(data.Number);
            for(int i = 0; i < LineSets.Count; i++)
            {
                for(int j = 0; j < LineSets[i].Length; j++)
                {
                    for(int k = 0; k < data.Number.Count; k++)
                    {
                        if(LineSets[i][j].ToString() == data.Number[k].ToString())
                        {
                            finalPrice += data.Price[k];
                            finalWeight += data.Weight[k];
 

                        }
                    }
                }
                if(finalWeight <= data.LimitWeight)
                {
                    finalList.Add("Номера предметов: " + "{" + LineSets[i] + " Стоимость предметов: " + finalPrice.ToString() + " Вес предметов: " + finalWeight.ToString());
                    if(finalPrice > countPrice)
                    {
                        answerForSolve = "Номера предметов: " + "{" + LineSets[i] + " Стоимость предметов: " + finalPrice.ToString() + " Вес предметов: " + finalWeight.ToString();
                        countPrice = finalPrice;
                    }
                }
                finalPrice = 0;
                finalWeight = 0;
            }



            return answerForSolve;

        }




        

    }


}
