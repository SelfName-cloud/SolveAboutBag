﻿using System;
using SAB;
using System.Collections.Generic;

namespace SAB
{
    class Program
    {
        static void Main(string[] args)
        {
            SolveAboutBag sab = new SolveAboutBag();
            List<int> number = new List<int>();
            List<int> price = new List<int>();
            List<int> weight = new List<int>();
            int limitWeight;
            Console.WriteLine("Задача о рюкзаке. Чтобы начать нажмите 'y' или Enter: ");
            var userReady = Console.ReadLine();
            if((userReady == "")||(char.Parse(userReady) == 'y'))
            {
                Console.WriteLine("Введите количество предметов, которые нужно уложить в рюкзак: ");
                var countThings = int.Parse(Console.ReadLine());
                /*
                if (countThings >= 10)
                {
                    Console.WriteLine("Количество предметов должно быть не больше 9. Пожалуйста, введите заново: ");
                    countThings = int.Parse(Console.ReadLine());
                    
                }*/
                int i;
                for(i = 1; i < countThings + 1;i++)
                {
                    number.Add(i);

                    Console.WriteLine("Введите цену для " + i.ToString() + " предмета: ");
                    var countPrice = int.Parse(Console.ReadLine());
                    price.Add(countPrice);

                    Console.WriteLine("Введите вес для " + i.ToString() + " предмета: ");
                    var countWeight = int.Parse(Console.ReadLine());
                    weight.Add(countWeight);

                }
                Console.WriteLine("Введите максимальный вес рюкзака: ");
                limitWeight = int.Parse(Console.ReadLine());
                Console.WriteLine("Результат работы программы: ");
 
                Console.WriteLine(sab.SolveAboutBagMethod(number, price, weight, limitWeight));

            }
            else
            {
                Console.WriteLine("Чтобы выйти нажмите на любую клавишу.");
                Console.ReadKey();
            }

            
            
          
           
            
            
            
            
            
            
        }
    }
}
